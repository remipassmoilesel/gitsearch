#!/usr/bin/env bash

set -e

fakeCommit () {
  c_date=$1

  echo "${c_date}" > "${c_date}.txt"
  git add "${c_date}.txt"
  GIT_AUTHOR_DATE="${c_date}" GIT_COMMITTER_DATE="${c_date}" git commit -m "Commit ${c_date}"
}

git init

fakeCommit "Sun Jul 28 14:00 2019 +0100"
fakeCommit "Sun Jul 28 14:15 2019 +0100"
fakeCommit "Sun Jul 28 14:30 2019 +0100"
fakeCommit "Sun Jul 28 14:45 2019 +0100"
fakeCommit "Sun Jul 28 15:00 2019 +0100"
fakeCommit "Sun Jul 28 15:15 2019 +0100"
fakeCommit "Sun Jul 28 15:30 2019 +0100"
fakeCommit "Sun Jul 28 15:45 2019 +0100"
fakeCommit "Sun Jul 28 16:00 2019 +0100"
fakeCommit "Sun Jul 28 16:15 2019 +0100"
