#!/usr/bin/env bash
# 2

echo "Hello world !"