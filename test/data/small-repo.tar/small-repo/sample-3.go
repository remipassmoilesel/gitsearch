package small_repo

import "fmt"

func main() {
	fmt.Println("Hello world !")
}
